import Board from './Components/Board/Board'


function App() {
  return (
    <div>
      <Board />
    </div>
  );
}

export default App;
